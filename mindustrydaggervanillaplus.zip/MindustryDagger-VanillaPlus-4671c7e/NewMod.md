# VanillaPlus
VanillaPlus mod for Mindustry. I'm Russian

Hello everyone, I'm probably will be working on a new project.. I decide what will I do. I'm start working on it since today-tomorrow.
This mod will 'example' for new project.
Goodbye all, please waiting news...
Всем привет, я скорее всего начну работать над новым проектом.. Я решил, что буду делать. Я начну работать либо сегодня, либо завтра.
Этот мод будет 'образцом' для нового проекта
Всем пока, ожидайте новостей...
